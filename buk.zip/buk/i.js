(function() {
	(document.createElement('IMG')).src = 'https://cm.idealmedia.io/setmuidn/?muidf=l1lEZ_fkh3b7';
	(document.createElement('IMG')).src = 'https://sync.crwdcntrl.net/map/c=14777/tp=MIGD/tpid=l1lEZ_fkh3b7';
	(document.createElement('IMG')).src = 'https://dm.hybrid.ai/match?id=152&vid=l1lEZ_fkh3b7';
	(document.createElement('IMG')).src = 'https://creativecdn.com/cm-notify?pi=mgid';
	let d43070 = document.createElement('div');d43070.innerHTML="<iframe id=\"multisync-iframe\" height=\"0\" width=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\" frameborder=\"0\" src=\"https://secure-assets.rubiconproject.com/utils/xapi/multi-sync.html?p=mgid&endpoint=eu\" style=\"border: 0px; display: none;\"></iframe>";document.body.appendChild(d43070);
	(document.createElement('IMG')).src = 'https://x.bidswitch.net/sync?dsp_id=303&user_id=l1lEZ_fkh3b7';
	(document.createElement('IMG')).src = 'https://cm.g.doubleclick.net/pixel?google_nid=marketgid&google_cm=&google_ula={guid}&google_hm=bDFsRVpfZmtoM2I3&muidn=l1lEZ_fkh3b7';
	(document.createElement('IMG')).src = 'https://x01.aidata.io/0.gif?pid=1939509&id=l1lEZ_fkh3b7';
	(document.createElement('IMG')).src = 'https://x.bidswitch.net/sync?ssp=mgid';
	(document.createElement('IMG')).src = 'https://inv-nets.admixer.net/adxcm.aspx?ssp=6B6764B0-A8A2-472C-AD41-0A3ACA1CE3B2&rurl=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D549405%26c%3D%24%24visitor_cookie%24%24';
	(document.createElement('IMG')).src = 'https://match.adsrvr.org/track/cmf/generic?ttd_pid=omn67hl&ttd_tpi=1';
	(document.createElement('IMG')).src = 'https://cm.lentainform.com/setmuidn/?muidf=l1lEZ_fkh3b7';
})()
