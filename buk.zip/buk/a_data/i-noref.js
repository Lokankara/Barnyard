(function() {
	(document.createElement('IMG')).src = 'https://t.trafmag.com/images/1px-matching-mgid.gif?id=l1lEZ_fkh3b7';
	(document.createElement('IMG')).src = 'https://ssp.adriver.ru/cgi-bin/sync.cgi?ssp_id=63&external_id=l1lEZ_fkh3b7';
	(document.createElement('IMG')).src = 'https://recreativ.ru/mtch/13/l1lEZ_fkh3b7/?fredir=1';
})()
